package com.example.assement5.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data @AllArgsConstructor
public class Teacher {
    @NotNull( message = "Should be not null")
    private Integer id;
    @NotEmpty (message = "Should be not null")
    private String name;
    @NotNull (message = "Should be not null")
    private Integer salary;

}



