package com.example.assement5.Service;

import com.example.assement5.model.Student;
import com.example.assement5.model.Teacher;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class TeacherService {
    ArrayList<Teacher> teachers =new ArrayList() ;


    public ArrayList<Teacher> getTeacher() {
        return teachers;
    }

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
    }

    public boolean updateTeacher(Integer id, Teacher teacher) {
            for(int i =0; i<teachers .size() ; i++){
                if(teachers.get(i) .getId()==id){
                    teachers.set(i,teacher);
                    return true;
                }
            }
            return false;
        }

    public boolean deleteTeacher(Integer id, Teacher teacher) {
            for(int i =0; i<teachers.size() ; i++){
                if(teachers.get(i).getId()==id){
                    teachers.remove(i) ;
                    return true;
                }
            }
            return false;
        }
    public Teacher getName(String name) {
        for (int i = 0; i < teachers.size() ; i++) {
            if(teachers.get(i).getName().equals(name))
                return teachers.get(i);
        }
        return null;
    }
    public ArrayList<Teacher> getSalary(Integer salary) {
        ArrayList<Teacher> salarys = new ArrayList<>();
        for (int i = 0; i < teachers.size() ; i++) {
            if(teachers.get(i).getSalary() >= salary)
                salarys.add(teachers.get(i));
        }
        return salarys;
    }
    }


