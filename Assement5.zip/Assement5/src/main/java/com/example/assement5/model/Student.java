package com.example.assement5.model;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

@Data @AllArgsConstructor
public class Student {
    @NotNull(message = "Should be not null")
    private Integer id;
    @NotEmpty (message = "Should be not null")
    private String name;
    @NotNull(message = "Should be not null")
    private Integer age;
    @NotEmpty (message = "Should be not null")
    @Pattern(regexp = "(CS | MATH | Engineer)")
    private String major;
}
