package com.example.assement5.Controller;

import com.example.assement5.Service.StudentService;
import com.example.assement5.Service.TeacherService;
import com.example.assement5.model.ApiResponse;
import com.example.assement5.model.Student;
import com.example.assement5.model.Teacher;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController @RequestMapping("/api/v1")
public class TeacherController {
    private TeacherService teacherService ;
    public TeacherController  (TeacherService teacherService ) {

        this.teacherService = teacherService;
    }
    @GetMapping("/get")
    public ResponseEntity getBlog() {
        ArrayList<Teacher> teachers = teacherService .getTeacher();
        return ResponseEntity.status(200).body(teachers);

    }
    @PostMapping("/add")
    public ResponseEntity addTeacher(@RequestBody @Valid Teacher teacher , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        teacherService.addTeacher(teacher);
        return ResponseEntity.status(200).body(new ApiResponse("Teacher Added!") );
    }
    @PutMapping("/update/{index}")
    public ResponseEntity updateTeacher(@PathVariable Integer id, @RequestBody @Valid Teacher teacher , Errors error) {
         if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        boolean isUpdated = teacherService.updateTeacher(id , teacher );
        if (isUpdated) {
            return ResponseEntity.status(200).body(new ApiResponse("Teacher update!"));
        }
        return ResponseEntity.status(400).body(new ApiResponse("wrong id!"));
    }
    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deleteTeacher(@PathVariable Integer id , @RequestBody @Valid Teacher teacher , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        boolean isDeleted = teacherService.deleteTeacher(id, teacher);
        if (isDeleted) {
            return ResponseEntity.status(200).body(new ApiResponse("Teacher Delete!"));
        }
        return ResponseEntity.status(400).body(new ApiResponse("wrong id!"));
    }

}
