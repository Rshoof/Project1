package com.example.assement5.Controller;

import com.example.assement5.Service.StudentService;
import com.example.assement5.model.ApiResponse;
import com.example.assement5.model.Student;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController @RequestMapping("/api/v1")
public class StudentController {

    private StudentService studentService;
    public StudentController (StudentService studentService ) {

        this.studentService = studentService;
    }
    @GetMapping("/get")
    public ResponseEntity getBlog() {
        ArrayList<Student> students = studentService.getStudents();
        return ResponseEntity.status(200).body(students);

    }
    @PostMapping("/add")
    public ResponseEntity addStudent(@RequestBody @Valid Student  student, Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        studentService.addStudent(student);
        return ResponseEntity.status(200).body(new ApiResponse("Student Added!") );
    }
    @PutMapping("/update/{index}")
    public ResponseEntity updateStudent(@PathVariable Integer id, @RequestBody @Valid Student  student , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        boolean isUpdated = studentService.updateStudent(id , student );
        if (isUpdated) {
            return ResponseEntity.status(200).body(new ApiResponse("Student update!"));
        }
        return ResponseEntity.status(400).body(new ApiResponse("wrong id!"));
    }
    @DeleteMapping ("/delete/{index}")
    public ResponseEntity deletStudent(@PathVariable Integer id , @RequestBody @Valid Student  student , Errors error) {
        if (error.hasErrors()) {
            String message = error.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(message);
        }
        boolean isDeleted = studentService.deletStudent(id, student);
        if (isDeleted) {
            return ResponseEntity.status(200).body(new ApiResponse("Student Delete!"));
        }
        return ResponseEntity.status(400).body(new ApiResponse("wrong id!"));
    }

}
