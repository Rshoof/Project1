package com.example.assement5.Service;

import com.example.assement5.model.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class StudentService {
    ArrayList<Student > students =new ArrayList() ;


    public ArrayList<Student> getStudents() {
        return students;

    }

    public void addStudent(Student student) {
        students.add(student);

    }

    public boolean updateStudent(Integer id, Student student) {
        for(int i =0; i<students .size() ; i++){
            if(students.get(i) .getId()==id){
                students.set(i,student);
                return true;
            }
        }
        return false;

    }

    public boolean deletStudent(Integer id, Student student) {
         for(int i =0; i<students .size() ; i++){
                if(students .get(i).getId()==id){
                    students.remove(i) ;
                    return true;
                }
            }
            return false;
        }
        public Student getId(int id){
        for(int i = 0; i< students.size(); i++){
            if(students.get(i).getId()==id)
                return students.get(i);
        }
        return null;
        }
        public Student getName(String name){
            for(int i = 0; i< students.size(); i++){
                if(students.get(i).getName().equals(name))
                    return students.get(i);
            }
            return null;
        }
    public ArrayList<Student> getMajor(String major) {
        ArrayList<Student> majorr = new ArrayList<>();
        for (int i = 0; i < students.size() ; i++) {
            if(students.get(i).getMajor().equals(major))
                majorr.add(students.get(i));
        }
        return majorr;
    }
    public ArrayList<Student> getAge(Integer age) {
        ArrayList<Student> ages = new ArrayList<>();
        for (int i = 0; i < students.size() ; i++) {
            if(students.get(i).getAge() >= age)
                ages.add(students.get(i));
        }
        return ages;
    }

    }


